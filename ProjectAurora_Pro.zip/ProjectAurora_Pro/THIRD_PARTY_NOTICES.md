# Third-party notices

## Signalsmith Stretch

Project Aurora uses Signalsmith Stretch, a C++ pitch/time-stretching library by Signalsmith Audio.
Repository: https://github.com/Signalsmith-Audio/signalsmith-stretch
License: MIT License (see the upstream `LICENSE.txt` file). The library is fetched at configure time by CMake at a pinned revision. The upstream licence text and any bundled dependency notices are authoritative; retain them when redistributing the library or binaries containing it.

## JUCE

JUCE is a separate third-party framework. It is not bundled in this repository; the build points to the user's local JUCE checkout through `JUCE_DIR`. Review the applicable JUCE licence terms before distributing the plugin.
