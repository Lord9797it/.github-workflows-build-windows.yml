# Changelog

## 0.5.0 — DSP engine upgrade

- Replaced the experimental dual-delay pitch shifter with Signalsmith Stretch integration.
- Added 12 musical scale modes.
- Added fine tuning in cents.
- Added target-note hysteresis to reduce rapid target switching near scale boundaries.
- Added central GUI target note/correction telemetry.
- Added CMake targets for quantizer and pitch detector smoke tests.
- Removed inactive Dry/Wet and plugin-bypass controls rather than exposing controls without correct implementation.
- Added third-party notices and engineering limitations documentation.
