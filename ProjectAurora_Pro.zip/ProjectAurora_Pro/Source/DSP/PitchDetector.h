#pragma once

#include <array>
#include <atomic>
#include <cmath>
#include <cstddef>

namespace aurora
{
struct PitchEstimate
{
    float frequencyHz = 0.0f;
    float confidence = 0.0f;
    bool voiced = false;
};

// Real-time monophonic pitch detector based on a decimated YIN difference function.
// Fixed-size storage only; processSample() performs no allocation or locking.
class PitchDetector final
{
public:
    static constexpr int windowSize = 1024;
    static constexpr int hopSize = 256;

    void prepare (double sampleRate) noexcept;
    void reset() noexcept;
    void processSample (float sample) noexcept;

    PitchEstimate getLatestEstimate() const noexcept;
    double getSampleRate() const noexcept { return sampleRate; }

private:
    PitchEstimate analyseWindow() noexcept;

    double sampleRate = 44100.0;
    std::array<float, windowSize> ring {};
    std::array<float, windowSize / 2> decimated {};
    std::array<float, windowSize / 2> difference {};
    std::size_t writeIndex = 0;
    int samplesSinceAnalysis = 0;
    int samplesCollected = 0;
    float previousFrequency = 0.0f;
    std::atomic<float> latestFrequency { 0.0f };
    std::atomic<float> latestConfidence { 0.0f };
    std::atomic<bool> latestVoiced { false };
};

const char* noteNameFromMidi (int midiNote) noexcept;
int frequencyToMidiNote (float frequencyHz) noexcept;
float frequencyToCentsFromNearestNote (float frequencyHz) noexcept;
}
