#include "PitchDetector.h"
#include <algorithm>
#include <limits>

namespace aurora
{
void PitchDetector::prepare (double newSampleRate) noexcept
{
    sampleRate = (newSampleRate > 1000.0 ? newSampleRate : 44100.0);
    reset();
}

void PitchDetector::reset() noexcept
{
    ring.fill (0.0f);
    decimated.fill (0.0f);
    difference.fill (0.0f);
    writeIndex = 0;
    samplesSinceAnalysis = 0;
    samplesCollected = 0;
    previousFrequency = 0.0f;
    latestFrequency.store (0.0f, std::memory_order_relaxed);
    latestConfidence.store (0.0f, std::memory_order_relaxed);
    latestVoiced.store (false, std::memory_order_relaxed);
}

void PitchDetector::processSample (float sample) noexcept
{
    if (! std::isfinite (sample))
        sample = 0.0f;

    ring[writeIndex] = sample;
    writeIndex = (writeIndex + 1) % ring.size();
    samplesCollected = std::min (samplesCollected + 1, windowSize);
    ++samplesSinceAnalysis;

    if (samplesCollected >= windowSize && samplesSinceAnalysis >= hopSize)
    {
        samplesSinceAnalysis = 0;
        const auto estimate = analyseWindow();
        latestFrequency.store (estimate.frequencyHz, std::memory_order_relaxed);
        latestConfidence.store (estimate.confidence, std::memory_order_relaxed);
        latestVoiced.store (estimate.voiced, std::memory_order_relaxed);
        if (estimate.voiced)
            previousFrequency = estimate.frequencyHz;
    }
}

PitchEstimate PitchDetector::getLatestEstimate() const noexcept
{
    PitchEstimate result;
    result.frequencyHz = latestFrequency.load (std::memory_order_relaxed);
    result.confidence = latestConfidence.load (std::memory_order_relaxed);
    result.voiced = latestVoiced.load (std::memory_order_relaxed);
    return result;
}

PitchEstimate PitchDetector::analyseWindow() noexcept
{
    // Read the latest 1024 samples oldest-to-newest, applying 2:1 decimation.
    constexpr int n = windowSize / 2;
    for (int i = 0; i < n; ++i)
    {
        const auto idx = (writeIndex + static_cast<std::size_t> (i * 2)) % ring.size();
        decimated[static_cast<std::size_t> (i)] = ring[idx];
    }

    double energy = 0.0;
    for (float x : decimated)
        energy += static_cast<double> (x) * x;
    const float rms = static_cast<float> (std::sqrt (energy / n));
    if (rms < 0.0025f)
        return {};

    const double detectorRate = sampleRate * 0.5;
    const int minLag = std::max (2, static_cast<int> (detectorRate / 1000.0));
    const int maxLag = std::min (n - 2, static_cast<int> (detectorRate / 50.0));
    if (maxLag <= minLag)
        return {};

    difference.fill (0.0f);
    for (int lag = 1; lag <= maxLag; ++lag)
    {
        double sum = 0.0;
        const int limit = n - lag;
        for (int i = 0; i < limit; ++i)
        {
            const float delta = decimated[static_cast<std::size_t> (i)]
                              - decimated[static_cast<std::size_t> (i + lag)];
            sum += static_cast<double> (delta) * delta;
        }
        difference[static_cast<std::size_t> (lag)] = static_cast<float> (sum);
    }

    // Cumulative mean normalized difference function (YIN-style).
    double runningSum = 0.0;
    std::array<float, n> cmnd {};
    cmnd[0] = 1.0f;
    for (int lag = 1; lag <= maxLag; ++lag)
    {
        runningSum += difference[static_cast<std::size_t> (lag)];
        cmnd[static_cast<std::size_t> (lag)] = runningSum > 1.0e-15
            ? static_cast<float> (difference[static_cast<std::size_t> (lag)] * lag / runningSum)
            : 1.0f;
    }

    constexpr float threshold = 0.18f;
    int selectedLag = -1;
    for (int lag = minLag; lag <= maxLag; ++lag)
    {
        if (cmnd[static_cast<std::size_t> (lag)] < threshold)
        {
            while (lag + 1 <= maxLag && cmnd[static_cast<std::size_t> (lag + 1)]
                                         < cmnd[static_cast<std::size_t> (lag)])
                ++lag;
            selectedLag = lag;
            break;
        }
    }

    if (selectedLag < 0)
    {
        float best = std::numeric_limits<float>::max();
        for (int lag = minLag; lag <= maxLag; ++lag)
        {
            const float value = cmnd[static_cast<std::size_t> (lag)];
            if (value < best)
            {
                best = value;
                selectedLag = lag;
            }
        }
        if (selectedLag < 0 || best > 0.35f)
            return {};
    }

    // Parabolic interpolation around the minimum improves sub-sample lag accuracy.
    float refinedLag = static_cast<float> (selectedLag);
    if (selectedLag > minLag && selectedLag < maxLag)
    {
        const float left = cmnd[static_cast<std::size_t> (selectedLag - 1)];
        const float centre = cmnd[static_cast<std::size_t> (selectedLag)];
        const float right = cmnd[static_cast<std::size_t> (selectedLag + 1)];
        const float denominator = left - 2.0f * centre + right;
        if (std::abs (denominator) > 1.0e-7f)
            refinedLag += 0.5f * (left - right) / denominator;
    }

    if (refinedLag <= 0.0f)
        return {};

    const float frequency = static_cast<float> (detectorRate / refinedLag);
    const float confidence = std::max (0.0f, std::min (1.0f, 1.0f - cmnd[static_cast<std::size_t> (selectedLag)]));
    return { frequency, confidence, confidence >= 0.55f };
}

const char* noteNameFromMidi (int midiNote) noexcept
{
    static constexpr const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    const int pitchClass = ((midiNote % 12) + 12) % 12;
    return names[pitchClass];
}

int frequencyToMidiNote (float frequencyHz) noexcept
{
    if (! std::isfinite (frequencyHz) || frequencyHz <= 0.0f)
        return -1;
    return static_cast<int> (std::lround (69.0 + 12.0 * std::log2 (frequencyHz / 440.0)));
}

float frequencyToCentsFromNearestNote (float frequencyHz) noexcept
{
    if (! std::isfinite (frequencyHz) || frequencyHz <= 0.0f)
        return 0.0f;
    const double midi = 69.0 + 12.0 * std::log2 (frequencyHz / 440.0);
    return static_cast<float> ((midi - std::round (midi)) * 100.0);
}
}
