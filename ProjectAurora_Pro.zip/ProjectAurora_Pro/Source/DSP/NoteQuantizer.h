#pragma once
namespace aurora
{
enum class ScaleType : int
{
    Chromatic = 0,
    Major,
    NaturalMinor,
    HarmonicMinor,
    MelodicMinor,
    Dorian,
    Phrygian,
    Lydian,
    Mixolydian,
    Locrian,
    MajorPentatonic,
    MinorPentatonic
};
struct QuantizedPitch
{
    int midiNote = -1;
    float targetHz = 0.0f;
    float centsFromTarget = 0.0f;
};
class NoteQuantizer final
{
public:
    static QuantizedPitch quantize (float frequencyHz, int key, ScaleType scale, float amount) noexcept;
    static bool noteAllowed (int midiNote, int key, ScaleType scale) noexcept;
};
}
