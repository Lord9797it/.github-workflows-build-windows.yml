#pragma once

#include <array>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <signalsmith-stretch.h>

namespace aurora
{
// High-quality streaming pitch/time engine based on Signalsmith Stretch (MIT).
// Processing is block-based and has non-zero algorithmic latency. Call prepare()
// before audio processing; process() performs no resizing or allocation.
class SignalsmithPitchEngine final
{
public:
    static constexpr int maxChannels = 2;
    static constexpr int chunkSize = 256;

    void prepare (double sampleRate, int channels)
    {
        channels = std::clamp (channels, 1, maxChannels);
        sr = sampleRate > 1000.0 ? sampleRate : 44100.0;
        numChannels = channels;
        stretch.presetDefault (numChannels, static_cast<float> (sr));
        stretch.setTransposeSemitones (0.0f);
        for (auto& ch : inputScratch) ch.assign (chunkSize, 0.0f);
        for (auto& ch : outputScratch) ch.assign (chunkSize, 0.0f);
        reset();
    }

    void reset() noexcept
    {
        stretch.reset();
        semitones = targetSemitones = 0.0f;
    }

    void setTransposeSemitones (float value) noexcept
    {
        targetSemitones = std::clamp (std::isfinite (value) ? value : 0.0f, -12.0f, 12.0f);
    }

    // Interleaving is avoided: JUCE supplies planar channel buffers. The output
    // scratch is distinct because Signalsmith does not allow input/output aliasing.
    void process (float* const* channels, int channelCount, int numSamples,
                  float speedMs, double sampleRate) noexcept
    {
        if (numChannels < 1 || numSamples <= 0 || channels == nullptr)
            return;

        const float safeSr = static_cast<float> (sampleRate > 1000.0 ? sampleRate : sr);
        const float tau = std::max (1.0f, speedMs) * 0.001f;
        const float smoothing = 1.0f - std::exp (-static_cast<float> (chunkSize) / (safeSr * tau));
        int offset = 0;
        while (offset < numSamples)
        {
            const int n = std::min (chunkSize, numSamples - offset);
            semitones += smoothing * (targetSemitones - semitones);
            stretch.setTransposeSemitones (semitones);

            std::array<float*, maxChannels> inPtrs { nullptr, nullptr };
            std::array<float*, maxChannels> outPtrs { nullptr, nullptr };
            for (int ch = 0; ch < numChannels; ++ch)
            {
                auto& in = inputScratch[static_cast<size_t> (ch)];
                auto& out = outputScratch[static_cast<size_t> (ch)];
                if (ch < channelCount && channels[ch] != nullptr)
                    std::copy_n (channels[ch] + offset, n, in.data());
                else
                    std::fill_n (in.data(), n, 0.0f);
                inPtrs[static_cast<size_t> (ch)] = in.data();
                outPtrs[static_cast<size_t> (ch)] = out.data();
            }
            stretch.process (inPtrs.data(), n, outPtrs.data(), n);
            for (int ch = 0; ch < std::min (channelCount, numChannels); ++ch)
                if (channels[ch] != nullptr)
                    std::copy_n (outputScratch[static_cast<size_t> (ch)].data(), n, channels[ch] + offset);
            offset += n;
        }
    }

    int latencySamples() const noexcept
    {
        return stretch.inputLatency() + stretch.outputLatency();
    }

private:
    signalsmith::stretch::SignalsmithStretch<float> stretch;
    std::array<std::vector<float>, maxChannels> inputScratch;
    std::array<std::vector<float>, maxChannels> outputScratch;
    double sr = 44100.0;
    int numChannels = 2;
    float semitones = 0.0f;
    float targetSemitones = 0.0f;
};
} // namespace aurora
