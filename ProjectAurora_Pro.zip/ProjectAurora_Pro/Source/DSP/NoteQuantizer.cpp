#include "NoteQuantizer.h"
#include <algorithm>
#include <array>
#include <cmath>

namespace aurora
{
namespace
{
using Scale = std::array<int, 7>;
constexpr Scale major { 0, 2, 4, 5, 7, 9, 11 };
constexpr Scale naturalMinor { 0, 2, 3, 5, 7, 8, 10 };
constexpr Scale harmonicMinor { 0, 2, 3, 5, 7, 8, 11 };
constexpr Scale melodicMinor { 0, 2, 3, 5, 7, 9, 11 };
constexpr Scale dorian { 0, 2, 3, 5, 7, 9, 10 };
constexpr Scale phrygian { 0, 1, 3, 5, 7, 8, 10 };
constexpr Scale lydian { 0, 2, 4, 6, 7, 9, 11 };
constexpr Scale mixolydian { 0, 2, 4, 5, 7, 9, 10 };
constexpr Scale locrian { 0, 1, 3, 5, 6, 8, 10 };
constexpr std::array<int, 5> majorPentatonic { 0, 2, 4, 7, 9 };
constexpr std::array<int, 5> minorPentatonic { 0, 3, 5, 7, 10 };
float midiToHz (float midi) noexcept { return 440.0f * std::pow (2.0f, (midi - 69.0f) / 12.0f); }
}

bool NoteQuantizer::noteAllowed (int midi, int key, ScaleType scale) noexcept
{
    if (scale == ScaleType::Chromatic)
        return true;
    const int pitchClass = ((midi % 12) + 12) % 12;
    const int relative = (pitchClass - ((key % 12) + 12) % 12 + 12) % 12;
    auto inScale = [relative] (const auto& intervals)
    {
        for (int interval : intervals)
            if (relative == interval) return true;
        return false;
    };
    switch (scale)
    {
        case ScaleType::Major: return inScale (major);
        case ScaleType::NaturalMinor: return inScale (naturalMinor);
        case ScaleType::HarmonicMinor: return inScale (harmonicMinor);
        case ScaleType::MelodicMinor: return inScale (melodicMinor);
        case ScaleType::Dorian: return inScale (dorian);
        case ScaleType::Phrygian: return inScale (phrygian);
        case ScaleType::Lydian: return inScale (lydian);
        case ScaleType::Mixolydian: return inScale (mixolydian);
        case ScaleType::Locrian: return inScale (locrian);
        case ScaleType::MajorPentatonic: return inScale (majorPentatonic);
        case ScaleType::MinorPentatonic: return inScale (minorPentatonic);
        case ScaleType::Chromatic: break;
    }
    return true;
}

QuantizedPitch NoteQuantizer::quantize (float hz, int key, ScaleType scale, float amount) noexcept
{
    QuantizedPitch out;
    if (! std::isfinite (hz) || hz <= 0.0f)
        return out;
    key = ((key % 12) + 12) % 12;
    amount = std::clamp (amount, 0.0f, 1.0f);
    const float rawMidi = 69.0f + 12.0f * std::log2 (hz / 440.0f);
    const int nearest = static_cast<int> (std::lround (rawMidi));
    int target = nearest;
    if (! noteAllowed (nearest, key, scale))
    {
        int bestDistance = 99;
        // Stable tie-break: prefer the lower target note, avoiding random note
        // switching exactly halfway between two allowed notes.
        for (int distance = 1; distance <= 6; ++distance)
        {
            if (noteAllowed (nearest - distance, key, scale)) { target = nearest - distance; bestDistance = distance; break; }
            if (noteAllowed (nearest + distance, key, scale) && distance < bestDistance) { target = nearest + distance; bestDistance = distance; }
        }
    }
    const float correctedMidi = rawMidi + (static_cast<float> (target) - rawMidi) * amount;
    out.midiNote = target;
    out.targetHz = midiToHz (correctedMidi);
    out.centsFromTarget = (rawMidi - static_cast<float> (target)) * 100.0f;
    return out;
}
}
