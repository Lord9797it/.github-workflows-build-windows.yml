#pragma once
#include <JuceHeader.h>
#include "DSP/PitchDetector.h"
#include "DSP/NoteQuantizer.h"
#include "DSP/SignalsmithPitchEngine.h"
#include <atomic>

class ProjectAuroraAudioProcessor final : public juce::AudioProcessor
{
public:
    ProjectAuroraAudioProcessor();
    ~ProjectAuroraAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    aurora::PitchEstimate getPitchEstimate() const noexcept { return pitchDetector.getLatestEstimate(); }
    float getTargetFrequency() const noexcept { return targetFrequency.load (std::memory_order_relaxed); }
    float getCorrectionCents() const noexcept { return correctionCents.load (std::memory_order_relaxed); }

    juce::AudioProcessorValueTreeState parameters;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> inputGainLinear;
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> outputGainLinear;
    double currentSampleRate = 44100.0;
    aurora::PitchDetector pitchDetector;
    aurora::SignalsmithPitchEngine pitchEngine;
    std::atomic<float> targetFrequency { 0.0f };
    std::atomic<float> correctionCents { 0.0f };
    int currentTargetMidi = -1;
    int previousKey = -1;
    int previousScale = -1;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProjectAuroraAudioProcessor)
};
