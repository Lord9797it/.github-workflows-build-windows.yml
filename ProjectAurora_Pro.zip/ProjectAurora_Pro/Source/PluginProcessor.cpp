#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

ProjectAuroraAudioProcessor::ProjectAuroraAudioProcessor()
    : AudioProcessor (BusesProperties()
        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "AURORA_STATE", createParameterLayout())
{}

juce::AudioProcessorValueTreeState::ParameterLayout ProjectAuroraAudioProcessor::createParameterLayout()
{
    using APF = juce::AudioParameterFloat;
    using APC = juce::AudioParameterChoice;
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    layout.add (std::make_unique<APF> (juce::ParameterID { "inputGain", 1 }, "Input Gain",
        juce::NormalisableRange<float> (-24.0f, 24.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("dB")));
    layout.add (std::make_unique<APF> (juce::ParameterID { "outputGain", 1 }, "Output Gain",
        juce::NormalisableRange<float> (-24.0f, 24.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("dB")));
    layout.add (std::make_unique<APC> (juce::ParameterID { "engineMode", 1 }, "Engine Mode",
        juce::StringArray { "Live", "Studio" }, 0));
    layout.add (std::make_unique<APF> (juce::ParameterID { "correctionSpeed", 1 }, "Correction Speed",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 72.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));
    layout.add (std::make_unique<APF> (juce::ParameterID { "correctionAmount", 1 }, "Correction Amount",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));
    layout.add (std::make_unique<APC> (juce::ParameterID { "key", 1 }, "Key",
        juce::StringArray { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" }, 0));
    layout.add (std::make_unique<APC> (juce::ParameterID { "scale", 1 }, "Scale",
        juce::StringArray { "Chromatic", "Major", "Natural Minor", "Harmonic Minor", "Melodic Minor", "Dorian", "Phrygian", "Lydian", "Mixolydian", "Locrian", "Major Pentatonic", "Minor Pentatonic" }, 0));
    layout.add (std::make_unique<APF> (juce::ParameterID { "fineTune", 1 }, "Fine Tune",
        juce::NormalisableRange<float> (-100.0f, 100.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("cent")));
    return layout;
}

void ProjectAuroraAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused (samplesPerBlock);
    currentSampleRate = sampleRate;
    pitchDetector.prepare (sampleRate);
    pitchEngine.prepare (sampleRate, getTotalNumOutputChannels());
    setLatencySamples (pitchEngine.latencySamples());
    targetFrequency.store (0.0f, std::memory_order_relaxed);
    correctionCents.store (0.0f, std::memory_order_relaxed);
    smoothedSemitones = 0.0f;
    currentTargetMidi = -1;
    previousKey = -1;
    previousScale = -1;
    inputGainLinear.reset (sampleRate, 0.02);
    outputGainLinear.reset (sampleRate, 0.02);
    inputGainLinear.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (*parameters.getRawParameterValue ("inputGain")));
    outputGainLinear.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (*parameters.getRawParameterValue ("outputGain")));
}

void ProjectAuroraAudioProcessor::releaseResources()
{
    pitchEngine.reset();
}

bool ProjectAuroraAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out;
}

void ProjectAuroraAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused (midi);
    juce::ScopedNoDenormals noDenormals;
    const int channels = std::min (2, getTotalNumInputChannels());
    const int outputChannels = std::min (2, getTotalNumOutputChannels());
    const int totalSamples = buffer.getNumSamples();
    for (int ch = channels; ch < outputChannels; ++ch)
        buffer.clear (ch, 0, totalSamples);

    inputGainLinear.setTargetValue (juce::Decibels::decibelsToGain (*parameters.getRawParameterValue ("inputGain")));
    outputGainLinear.setTargetValue (juce::Decibels::decibelsToGain (*parameters.getRawParameterValue ("outputGain")));
    const float amount = *parameters.getRawParameterValue ("correctionAmount") * 0.01f;
    const float speed = *parameters.getRawParameterValue ("correctionSpeed");
    const float fineTune = *parameters.getRawParameterValue ("fineTune");
    const bool studio = static_cast<int> (*parameters.getRawParameterValue ("engineMode")) == 1;
    const int key = static_cast<int> (*parameters.getRawParameterValue ("key"));
    const auto scale = static_cast<aurora::ScaleType> (static_cast<int> (*parameters.getRawParameterValue ("scale")));
    const float confidenceThreshold = studio ? 0.48f : 0.62f;
    const float smoothingMs = studio ? (220.0f - 218.0f * speed * 0.01f)
                                     : (120.0f - 118.0f * speed * 0.01f);

    // Work in small fixed chunks so pitch tracking and target updates can follow
    // the voice during a host block. The Signalsmith engine owns preallocated
    // scratch buffers and has its real latency reported to the host.
    constexpr int chunk = aurora::SignalsmithPitchEngine::chunkSize;
    for (int offset = 0; offset < totalSamples; offset += chunk)
    {
        const int n = std::min (chunk, totalSamples - offset);
        std::array<float*, 2> channelPtrs { nullptr, nullptr };
        for (int ch = 0; ch < channels; ++ch)
            channelPtrs[static_cast<size_t> (ch)] = buffer.getWritePointer (ch) + offset;

        float latestInputGain = 1.0f;
        for (int i = 0; i < n; ++i)
        {
            latestInputGain = inputGainLinear.getNextValue();
            float mono = 0.0f;
            for (int ch = 0; ch < channels; ++ch)
            {
                auto& sample = channelPtrs[static_cast<size_t> (ch)][i];
                sample *= latestInputGain;
                mono += sample;
            }
            if (channels > 0)
                mono /= static_cast<float> (channels);
            pitchDetector.processSample (mono);
        }

        const auto estimate = pitchDetector.getLatestEstimate();
        float wantedSemitones = 0.0f;
        if (amount > 0.0f && estimate.voiced && estimate.confidence >= confidenceThreshold
            && estimate.frequencyHz > 0.0f && std::isfinite (estimate.frequencyHz))
        {
            auto quantized = aurora::NoteQuantizer::quantize (estimate.frequencyHz, key, scale, amount);
            if (key != previousKey || static_cast<int> (scale) != previousScale
                || ! aurora::NoteQuantizer::noteAllowed (currentTargetMidi, key, scale))
                currentTargetMidi = -1;
            previousKey = key;
            previousScale = static_cast<int> (scale);

            if (quantized.targetHz > 0.0f && std::isfinite (quantized.targetHz))
            {
                const float rawMidi = 69.0f + 12.0f * std::log2 (estimate.frequencyHz / 440.0f);
                const int candidateMidi = quantized.midiNote;
                // Small note hysteresis prevents detector jitter from bouncing
                // between adjacent targets at a scale boundary. Scale/key edits
                // invalidate the previous target immediately.
                if (currentTargetMidi < 0 || candidateMidi == currentTargetMidi
                    || std::abs (rawMidi - static_cast<float> (candidateMidi)) + 0.12f
                       < std::abs (rawMidi - static_cast<float> (currentTargetMidi)))
                    currentTargetMidi = candidateMidi;

                const float correctedMidi = rawMidi + (static_cast<float> (currentTargetMidi) - rawMidi) * amount;
                const float correctedHz = 440.0f * std::pow (2.0f, (correctedMidi - 69.0f) / 12.0f);
                const float targetHz = correctedHz * std::pow (2.0f, fineTune / 1200.0f);
                wantedSemitones = 12.0f * std::log2 (targetHz / estimate.frequencyHz);
                targetFrequency.store (targetHz, std::memory_order_relaxed);
                correctionCents.store (wantedSemitones * 100.0f, std::memory_order_relaxed);
            }
        }
        else
        {
            targetFrequency.store (0.0f, std::memory_order_relaxed);
            correctionCents.store (0.0f, std::memory_order_relaxed);
            currentTargetMidi = -1;
        }

        pitchEngine.setTransposeSemitones (wantedSemitones);
        pitchEngine.process (channelPtrs.data(), channels, n, smoothingMs, currentSampleRate);

        std::array<float, aurora::SignalsmithPitchEngine::chunkSize> outputGains {};
        for (int i = 0; i < n; ++i)
            outputGains[static_cast<size_t> (i)] = outputGainLinear.getNextValue();
        for (int ch = 0; ch < outputChannels; ++ch)
        {
            auto* data = buffer.getWritePointer (ch) + offset;
            for (int i = 0; i < n; ++i)
                data[i] *= outputGains[static_cast<size_t> (i)];
        }
    }
}

juce::AudioProcessorEditor* ProjectAuroraAudioProcessor::createEditor()
{
    return new ProjectAuroraAudioProcessorEditor (*this);
}

void ProjectAuroraAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void ProjectAuroraAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName (parameters.state.getType()))
        parameters.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ProjectAuroraAudioProcessor();
}
