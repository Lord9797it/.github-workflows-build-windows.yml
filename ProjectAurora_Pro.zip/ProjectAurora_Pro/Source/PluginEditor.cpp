#include "PluginEditor.h"

namespace
{
    const juce::Colour bg       { 0xff101216 };
    const juce::Colour panel    { 0xff191d24 };
    const juce::Colour panel2   { 0xff202630 };
    const juce::Colour accent   { 0xff62e6d0 };
    const juce::Colour textMain { 0xfff1f4f8 };
    const juce::Colour textDim  { 0xff8c98a8 };
}

ProjectAuroraAudioProcessorEditor::ProjectAuroraAudioProcessorEditor (ProjectAuroraAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setResizable (true, true);
    setResizeLimits (760, 520, 1500, 1000);
    setSize (1040, 680);
    startTimerHz (30);

    title.setText ("AURORA", juce::dontSendNotification);
    title.setFont (juce::Font (juce::FontOptions (29.0f, juce::Font::bold)));
    title.setColour (juce::Label::textColourId, textMain);
    addAndMakeVisible (title);

    subtitle.setText ("VOCAL PITCH ENGINE  /  SIGNALSMITH DSP", juce::dontSendNotification);
    subtitle.setFont (juce::Font (juce::FontOptions (11.0f, juce::Font::bold)));
    subtitle.setColour (juce::Label::textColourId, accent);
    addAndMakeVisible (subtitle);

    pitchLabel.setText ("PITCH DETECTION  /  LIVE ANALYSIS", juce::dontSendNotification);
    pitchLabel.setJustificationType (juce::Justification::centred);
    pitchLabel.setFont (juce::Font (juce::FontOptions (18.0f, juce::Font::bold)));
    pitchLabel.setColour (juce::Label::textColourId, textMain);
    addAndMakeVisible (pitchLabel);

    statusLabel.setText ("PHASE 5  •  HIGH-QUALITY STRETCH ENGINE", juce::dontSendNotification);
    statusLabel.setJustificationType (juce::Justification::centred);
    statusLabel.setFont (juce::Font (juce::FontOptions (11.0f)));
    statusLabel.setColour (juce::Label::textColourId, textDim);
    addAndMakeVisible (statusLabel);

    styleSlider (inputGain, inputGainLabel, "INPUT GAIN");
    styleSlider (outputGain, outputGainLabel, "OUTPUT GAIN");
    styleSlider (correctionSpeed, speedLabel, "CORRECTION SPEED");
    styleSlider (correctionAmount, amountLabel, "CORRECTION AMOUNT");
    styleSlider (fineTune, fineTuneLabel, "FINE TUNE (CENT)");

    engineLabel.setText ("ENGINE MODE", juce::dontSendNotification);
    engineLabel.setFont (juce::Font (juce::FontOptions (11.0f, juce::Font::bold)));
    engineLabel.setColour (juce::Label::textColourId, textDim);
    addAndMakeVisible (engineLabel);
    engineMode.addItem ("LIVE", 1);
    engineMode.addItem ("STUDIO", 2);
    engineMode.setColour (juce::ComboBox::backgroundColourId, panel2);
    engineMode.setColour (juce::ComboBox::textColourId, textMain);
    engineMode.setColour (juce::ComboBox::outlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible (engineMode);

    auto& state = processor.parameters;
    inputGainAttachment = std::make_unique<SliderAttachment>(state, "inputGain", inputGain);
    outputGainAttachment = std::make_unique<SliderAttachment>(state, "outputGain", outputGain);
    speedAttachment = std::make_unique<SliderAttachment>(state, "correctionSpeed", correctionSpeed);
    amountAttachment = std::make_unique<SliderAttachment>(state, "correctionAmount", correctionAmount);
    fineTuneAttachment = std::make_unique<SliderAttachment>(state, "fineTune", fineTune);
    engineAttachment = std::make_unique<ComboAttachment>(state, "engineMode", engineMode);
    auto setupCombo = [this] (juce::ComboBox& box) { box.setColour(juce::ComboBox::backgroundColourId, panel2); box.setColour(juce::ComboBox::textColourId, textMain); box.setColour(juce::ComboBox::outlineColourId, juce::Colours::transparentBlack); addAndMakeVisible(box); };
    keyLabel.setText("KEY", juce::dontSendNotification); keyLabel.setColour(juce::Label::textColourId, textDim); keyLabel.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold))); addAndMakeVisible(keyLabel);
    scaleLabel.setText("SCALE", juce::dontSendNotification); scaleLabel.setColour(juce::Label::textColourId, textDim); scaleLabel.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold))); addAndMakeVisible(scaleLabel);
    keySelect.addItemList(juce::StringArray {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"}, 1); setupCombo(keySelect);
    scaleSelect.addItemList(juce::StringArray {"Chromatic", "Major", "Natural Minor", "Harmonic Minor", "Melodic Minor", "Dorian", "Phrygian", "Lydian", "Mixolydian", "Locrian", "Major Pentatonic", "Minor Pentatonic"}, 1); setupCombo(scaleSelect);
    keyAttachment = std::make_unique<ComboAttachment>(state, "key", keySelect);
    scaleAttachment = std::make_unique<ComboAttachment>(state, "scale", scaleSelect);
}

void ProjectAuroraAudioProcessorEditor::styleSlider (juce::Slider& slider, juce::Label& label, const juce::String& text)
{
    label.setText (text, juce::dontSendNotification);
    label.setFont (juce::Font (juce::FontOptions (11.0f, juce::Font::bold)));
    label.setColour (juce::Label::textColourId, textDim);
    label.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (label);
    slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 84, 22);
    slider.setColour (juce::Slider::rotarySliderFillColourId, accent);
    slider.setColour (juce::Slider::rotarySliderOutlineColourId, panel2);
    slider.setColour (juce::Slider::thumbColourId, textMain);
    slider.setColour (juce::Slider::textBoxTextColourId, textMain);
    slider.setColour (juce::Slider::textBoxBackgroundColourId, panel);
    slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible (slider);
}

void ProjectAuroraAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (bg);
    auto bounds = getLocalBounds().toFloat();
    g.setColour (accent.withAlpha (0.12f));
    g.fillRoundedRectangle (bounds.removeFromTop (5.0f), 2.0f);

    auto area = getLocalBounds().reduced (24);
    area.removeFromTop (72);
    auto display = area.removeFromTop (250).toFloat();
    g.setColour (panel);
    g.fillRoundedRectangle (display, 16.0f);
    auto inner = display.reduced (28.0f, 24.0f);
    g.setColour (panel2);
    g.drawRoundedRectangle (inner, 10.0f, 1.0f);

    // Pitch detection telemetry is read from atomics; no DSP work occurs in paint().
    g.setColour (textDim.withAlpha (0.28f));
    for (int i = 1; i < 12; ++i)
    {
        const float x = inner.getX() + inner.getWidth() * (float) i / 12.0f;
        g.drawVerticalLine ((int) x, inner.getY() + 10.0f, inner.getBottom() - 10.0f);
    }
    for (int i = 1; i < 5; ++i)
    {
        const float y = inner.getY() + inner.getHeight() * (float) i / 5.0f;
        g.drawHorizontalLine ((int) y, inner.getX() + 10.0f, inner.getRight() - 10.0f);
    }
    g.setColour (accent);
    g.setFont (juce::Font (juce::FontOptions (12.0f, juce::Font::bold)));
    const auto estimate = processor.getPitchEstimate();
    juce::String displayText = "Waiting for voiced input";
    if (estimate.voiced && estimate.frequencyHz > 0.0f)
    {
        const int midi = aurora::frequencyToMidiNote (estimate.frequencyHz);
        const int octave = midi >= 0 ? (midi / 12) - 1 : 0;
        displayText = juce::String (aurora::noteNameFromMidi (midi)) + juce::String (octave)
                    + "   |   " + juce::String (estimate.frequencyHz, 1) + " Hz   |   confidence "
                    + juce::String (estimate.confidence * 100.0f, 0) + "%";
    }
    auto displayBounds = inner.toNearestInt().reduced (8, 8);
    auto detectedLine = displayBounds.removeFromTop (displayBounds.getHeight() / 2);
    g.setFont (juce::Font (juce::FontOptions (22.0f, juce::Font::bold)));
    g.drawFittedText (displayText, detectedLine, juce::Justification::centred, 2);

    const float targetHz = processor.getTargetFrequency();
    juce::String targetText = "TARGET  —";
    if (targetHz > 0.0f)
    {
        const int targetMidi = aurora::frequencyToMidiNote (targetHz);
        const int targetOctave = targetMidi >= 0 ? (targetMidi / 12) - 1 : 0;
        targetText = "TARGET  " + juce::String (aurora::noteNameFromMidi (targetMidi))
                   + juce::String (targetOctave) + "   |   correction "
                   + juce::String (processor.getCorrectionCents(), 1) + " cent";
    }
    g.setColour (textDim);
    g.setFont (juce::Font (juce::FontOptions (15.0f, juce::Font::bold)));
    g.drawFittedText (targetText, displayBounds, juce::Justification::centred, 1);

    g.setColour (panel);
    g.fillRoundedRectangle (getLocalBounds().reduced (24).withTrimmedTop (340).toFloat(), 16.0f);
}

void ProjectAuroraAudioProcessorEditor::timerCallback()
{
    const auto estimate = processor.getPitchEstimate();
    if (estimate.voiced && estimate.frequencyHz > 0.0f)
        statusLabel.setText ("PHASE 5  •  CORRECTION ACTIVE  •  EXPERIMENTAL", juce::dontSendNotification);
    else
        statusLabel.setText ("PHASE 5  •  WAITING FOR VOICED INPUT", juce::dontSendNotification);
    repaint();
}

void ProjectAuroraAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    auto header = area.removeFromTop (64);
    title.setBounds (header.removeFromLeft (220));
    subtitle.setBounds (header.removeFromLeft (320).withY (22).withHeight (24));

    area.removeFromTop (8);
    auto display = area.removeFromTop (250);
    pitchLabel.setBounds (display.removeFromTop (42).reduced (8, 0));
    statusLabel.setBounds (display.removeFromBottom (28).reduced (8, 0));

    area.removeFromTop (12);
    auto knobRow = area.removeFromTop (145);
    const int colWidth = knobRow.getWidth() / 5;
    auto placeKnob = [] (juce::Rectangle<int> r, juce::Label& l, juce::Slider& s)
    {
        l.setBounds (r.removeFromTop (24));
        s.setBounds (r.reduced (5, 0));
    };
    placeKnob (knobRow.removeFromLeft (colWidth), inputGainLabel, inputGain);
    placeKnob (knobRow.removeFromLeft (colWidth), outputGainLabel, outputGain);
    placeKnob (knobRow.removeFromLeft (colWidth), speedLabel, correctionSpeed);
    placeKnob (knobRow.removeFromLeft (colWidth), amountLabel, correctionAmount);
    placeKnob (knobRow.removeFromLeft (colWidth), fineTuneLabel, fineTune);

    area.removeFromTop (4);
    auto selectors = area.removeFromTop (72);
    const int third = selectors.getWidth() / 3;
    auto keyArea = selectors.removeFromLeft (third); keyLabel.setBounds (keyArea.removeFromTop (20)); keySelect.setBounds (keyArea.removeFromTop (32).reduced (4, 0));
    auto scaleArea = selectors.removeFromLeft (third); scaleLabel.setBounds (scaleArea.removeFromTop (20)); scaleSelect.setBounds (scaleArea.removeFromTop (32).reduced (4, 0));
    engineLabel.setBounds (selectors.removeFromTop (20));
    engineMode.setBounds (selectors.removeFromTop (32).reduced (4, 0));
}
