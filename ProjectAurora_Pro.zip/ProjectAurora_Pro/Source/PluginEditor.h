#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class ProjectAuroraAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit ProjectAuroraAudioProcessorEditor (ProjectAuroraAudioProcessor&);
    ~ProjectAuroraAudioProcessorEditor() override = default;
    void paint (juce::Graphics&) override;
    void resized() override;
    void timerCallback() override;

private:
    ProjectAuroraAudioProcessor& processor;
    juce::Label title, subtitle, pitchLabel, statusLabel;
    juce::Slider inputGain, outputGain, correctionSpeed, correctionAmount, fineTune;
    juce::ComboBox engineMode, keySelect, scaleSelect;
    juce::Label inputGainLabel, outputGainLabel, speedLabel, amountLabel, fineTuneLabel, engineLabel, keyLabel, scaleLabel;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    std::unique_ptr<SliderAttachment> inputGainAttachment, outputGainAttachment,
                                      speedAttachment, amountAttachment, fineTuneAttachment;
    std::unique_ptr<ComboAttachment> engineAttachment, keyAttachment, scaleAttachment;
    void styleSlider (juce::Slider& slider, juce::Label& label, const juce::String& text);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ProjectAuroraAudioProcessorEditor)
};
