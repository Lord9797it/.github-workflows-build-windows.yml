# DSP tests

CMake builds two standalone test targets:

- `AuroraQuantizerTests`: basic key/scale quantization behavior.
- `AuroraPitchDetectorTests`: synthetic sine-wave pitch detection and silence rejection.

Run after configuring and building:

```powershell
ctest --test-dir build -C Release --output-on-failure
```

These are smoke tests, not a complete DSP quality suite. They do not test the Signalsmith engine, vocal recordings, latency, CPU or VST3 host integration.
