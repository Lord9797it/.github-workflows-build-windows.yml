#include "../Source/DSP/PitchDetector.h"
#include <cmath>
#include <iostream>

static bool testTone (float frequency, double sampleRate)
{
    aurora::PitchDetector detector;
    detector.prepare (sampleRate);
    constexpr double twoPi = 6.2831853071795864769;
    const int total = 8192;
    for (int i = 0; i < total; ++i)
    {
        const float sample = 0.35f * static_cast<float> (std::sin (twoPi * frequency * i / sampleRate));
        detector.processSample (sample);
    }
    const auto result = detector.getLatestEstimate();
    const float cents = result.frequencyHz > 0.0f ? 1200.0f * std::abs (std::log2 (result.frequencyHz / frequency)) : 9999.0f;
    const bool ok = result.voiced && result.frequencyHz > 0.0f && cents < 35.0f;
    std::cout << "tone " << frequency << " Hz: detected=" << result.frequencyHz
              << " Hz, confidence=" << result.confidence << ", " << (ok ? "PASS" : "FAIL") << '\n';
    return ok;
}

static bool testSilence()
{
    aurora::PitchDetector detector;
    detector.prepare (44100.0);
    for (int i = 0; i < 8192; ++i)
        detector.processSample (0.0f);
    const auto result = detector.getLatestEstimate();
    const bool ok = ! result.voiced && result.frequencyHz == 0.0f;
    std::cout << "silence: " << (ok ? "PASS" : "FAIL") << '\n';
    return ok;
}

int main()
{
    bool ok = true;
    ok &= testTone (110.0f, 44100.0);
    ok &= testTone (220.0f, 44100.0);
    ok &= testTone (440.0f, 48000.0);
    ok &= testTone (880.0f, 44100.0);
    ok &= testSilence();
    return ok ? 0 : 1;
}
