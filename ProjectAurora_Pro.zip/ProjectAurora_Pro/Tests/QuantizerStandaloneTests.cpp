#include "../Source/DSP/NoteQuantizer.h"
#include <cmath>
#include <iostream>

int main()
{
    int failures = 0;
    auto check = [&failures] (bool ok, const char* name)
    {
        std::cout << (ok ? "PASS: " : "FAIL: ") << name << '\n';
        if (! ok) ++failures;
    };
    const auto a4 = aurora::NoteQuantizer::quantize (440.0f, 0, aurora::ScaleType::Chromatic, 1.0f);
    check (a4.midiNote == 69 && std::abs (a4.targetHz - 440.0f) < 0.1f, "A4 maps to 440 Hz");
    const auto b4 = aurora::NoteQuantizer::quantize (493.883f, 0, aurora::ScaleType::Major, 1.0f);
    check (b4.midiNote == 71, "B4 remains in C major");
    const auto cSharp = aurora::NoteQuantizer::quantize (277.183f, 0, aurora::ScaleType::Major, 1.0f);
    check (cSharp.midiNote == 60 || cSharp.midiNote == 62, "C# snaps to a neighbouring C-major note");
    const auto untouched = aurora::NoteQuantizer::quantize (445.0f, 0, aurora::ScaleType::Chromatic, 0.0f);
    check (std::abs (untouched.targetHz - 445.0f) < 0.1f, "zero amount preserves input pitch");
    return failures == 0 ? 0 : 1;
}
