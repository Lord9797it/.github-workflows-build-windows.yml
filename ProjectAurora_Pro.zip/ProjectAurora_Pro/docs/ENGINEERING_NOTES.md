# DSP engineering notes

## Signal flow

1. Read host input and apply smoothed input gain.
2. Build a mono analysis signal from the input channels and feed the YIN-style pitch detector.
3. Estimate a target frequency from the selected key/scale and correction amount.
4. Convert the target/detected ratio to semitones, adding the Fine Tune offset.
5. Send the semitone target to Signalsmith Stretch.
6. Apply smoothed output gain and return audio to the host.

## Timing and latency

The stretch engine buffers audio internally. Project Aurora queries the engine's input and output latency and reports their sum to the host. This value must still be measured against actual output timing in a VST3 host. Host plugin-delay compensation is not a substitute for a loopback measurement.

## Real-time constraints

The engine scratch buffers are allocated in `prepare()`, not resized in `process()`. Host blocks are subdivided into chunks of at most 256 samples. Do not add file I/O, locks, heap allocation or GUI work to `processBlock()`.

## Known gaps

- Pitch detection currently uses a YIN-style difference function and is not a state-of-the-art vocal tracker.
- There is no robust voiced/unvoiced classifier or explicit onset detector yet.
- No note hysteresis or target-note hold policy is implemented.
- No formant preservation is implemented in the plugin's own UI/parameter model.
- No latency-aligned dry/wet path is exposed; it was intentionally removed rather than presenting an inactive or phase-misaligned control.
- Live/Studio are profiles, not independent engines.
- The code has not been built against the user's JUCE installation or validated in Cubase in this environment.
