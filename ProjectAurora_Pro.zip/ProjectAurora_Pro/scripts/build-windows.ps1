param(
    [Parameter(Mandatory = $true)]
    [string]$JuceDir,
    [ValidateSet("Debug", "Release")]
    [string]$Configuration = "Release"
)
$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$build = Join-Path $root "build"
cmake -S $root -B $build -G "Visual Studio 17 2022" -A x64 "-DJUCE_DIR=$JuceDir"
cmake --build $build --config $Configuration --target ProjectAurora_VST3 AuroraQuantizerTests
ctest --test-dir $build -C $Configuration --output-on-failure
